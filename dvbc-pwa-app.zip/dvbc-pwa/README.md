# De Voci Belli Chorale — Members App

This is a real, installable web app (PWA). Once it's hosted at a link, any
chorister can open that link on their phone and tap **"Add to Home Screen"**
to get an app icon that opens full-screen, just like a normal app —
no App Store needed.

Data (attendance, favorites) is saved on each person's own phone. It does
**not** sync between members yet — see "Next step" at the bottom.

---

## Deploy it (no coding needed) — about 10 minutes

You need two free accounts: **GitHub** and **Vercel**.

### 1. Put the code on GitHub
1. Go to [github.com](https://github.com) and sign up / log in.
2. Click the **+** in the top right → **New repository**.
3. Name it `dvbc-app` (or anything you like) → **Create repository**.
4. On the next page, click **"uploading an existing file"**.
5. Drag this entire project folder's contents into the browser window
   (everything except the `node_modules` folder, which you shouldn't have
   anyway) and click **Commit changes**.

### 2. Deploy it on Vercel
1. Go to [vercel.com](https://vercel.com) and sign up using your GitHub
   account (click **"Continue with GitHub"**).
2. Click **Add New… → Project**.
3. Find and **Import** the `dvbc-app` repository you just created.
4. Vercel will auto-detect it's a Vite app — leave all settings as-is.
5. Click **Deploy**. Wait about a minute.

You'll get a live link like `https://dvbc-app.vercel.app` — that's it, it's
live. Share that link in your choir group chat.

### 3. Installing it on a phone
Send the link to choristers. On each phone:
- **iPhone (Safari):** open the link → tap the Share icon → **Add to Home
  Screen**.
- **Android (Chrome):** open the link → tap the ⋮ menu → **Add to Home
  Screen** (or you'll see an automatic "Install app" banner).

The app icon (your logo) will appear on their home screen and open
full-screen, with no browser address bar.

---

## Alternative: Netlify

If you'd rather use Netlify instead of Vercel: create a free account at
[netlify.com](https://netlify.com), choose **"Import from Git"**, connect
the same GitHub repo, and click **Deploy**. Netlify also auto-detects Vite.

---

## Updating the app later

Any time you edit files in the GitHub repo (e.g. update the rehearsal
schedule or music list in `src/App.jsx`), Vercel/Netlify automatically
re-deploys the live link within a minute or two. Choristers don't need to
reinstall anything — refreshing the app updates it.

---

## For a developer, if you have one

Standard Vite + React project:
```
npm install
npm run dev      # local preview at http://localhost:5173
npm run build    # production build in /dist
```

---

## Next step: shared data across all members

Right now attendance and the music library live only on each person's own
phone (via browser storage) — there's no shared server. To have everyone
see the same live attendance sheet and music list, the app needs a real
backend, exactly as outlined in the original proposal (Supabase for
authentication, database, and storage). That's a separate build — happy to
start it when you're ready.
